<style>
*
{
	text-align:center;
	font-size:32px;
	padding:0;
	margin:0;
	min-width:auto;
	max-width:auto;
}
#calc
{
	background-color:grey;
}

#lcd
{
	background-color:black;
	color:green;
}

#ioc
{
		
}

button
{
	width:32px;
}
</style>
<center>
<div id="calc">
	<div>
		<div id="LCD">LCD Display</div> <!-- Display-->
		<div>
		<table>
			<tr>
				<td><button onclick="">7</button></td>
				<td><button onclick="">8</button></td>
				<td><button onclick="">9</button></td>
				<td><button onclick="">+</button></td>
			</tr>
			<tr>
				<td><button onclick="">4</button></td>
				<td><button onclick="">5</button></td>
				<td><button onclick="">6</button></td>
				<td><button onclick="">-</button></td>
			</tr>
			<tr>
				<td><button onclick="">1</button></td>
				<td><button onclick="">2</button></td>
				<td><button onclick="">3</button></td>
				<td><button onclick="">*</button></td>
			</tr>
			<tr>
				<td><button onclick="">0</button></td>
				<td><button onclick="">.</button></td>
				<td><button onclick="">=</button></td>
				<td><button onclick="">/</button></td>
			</tr>
		</table>
		</div><!-- Numbers-->		
	</div>
</div>
<?php




?>
